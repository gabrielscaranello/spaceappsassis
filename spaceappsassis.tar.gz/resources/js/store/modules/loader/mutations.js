const SET_LOADER = (state, obj) => {
  state.loader = obj;
};

export default {
  SET_LOADER,
};
