export default {
  loader: false,
};
