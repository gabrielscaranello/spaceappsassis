const setLoader = (context, obj) => {
  context.commit('SET_LOADER', obj);
};

export default {
  setLoader,
};
