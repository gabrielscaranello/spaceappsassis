export default {
  user: null,
};
