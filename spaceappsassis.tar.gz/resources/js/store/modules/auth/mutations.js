export default {
  SET_USER(state, obj) {
    state.user = obj;
  },
};
