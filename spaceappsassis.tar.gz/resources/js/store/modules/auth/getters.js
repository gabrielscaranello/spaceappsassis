export default {
  isLoged(state) {
    return !!state.user;
  },
};
