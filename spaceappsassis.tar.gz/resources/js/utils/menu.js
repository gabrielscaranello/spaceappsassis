const menu = [{
    icon: "dashboard",
    text: "Dashboard",
    link: "/admin",
}, {
    icon: "person",
    text: "Inscritos",
    link: "/admin/inscritos",
}];


export default menu;
