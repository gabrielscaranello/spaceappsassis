const unauthenticated = [
    '/',
    '/login'
];

export default unauthenticated;
