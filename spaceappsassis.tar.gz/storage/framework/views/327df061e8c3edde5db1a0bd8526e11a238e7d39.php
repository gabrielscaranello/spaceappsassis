<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>NASA Space Apps | Assis Chateubriand</title>

    
</head>

<body>

    <div id="app"></div>

    <script src="<?php echo e(mix('manifest.js')); ?>"></script>
    <script src="<?php echo e(mix('/js//vendor.js')); ?>"></script>
    <script src="<?php echo e(mix('/js//app.js')); ?>"></script>
</body>

</html>
<?php /**PATH /home/gabriel/code/github/spaceappsassis/resources/views/app.blade.php ENDPATH**/ ?>